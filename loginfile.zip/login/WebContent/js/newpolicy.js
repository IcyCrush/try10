

    // Function to calculate premium amount
    function premiumcalc() {
        var vehicleTypes = document.getElementById('vehicleTypes').value;
        var vehiclevalue = document.getElementById('vehiclevalue').value;
        var vehiclestate = document.getElementById('vehiclestate').value;
        var claimstatus = document.getElementById('claimstatus').value;
        var premiumAmount = document.getElementById('premiumAmount');
        var baseamount = 0;
        var total = 0;
        if (vehicleTypes === "2 Wheeler") {
            baseamount = 2500;
            vehiclevalue = vehiclevalue * 0.1;
            total = baseamount + vehiclevalue;
            if (vehiclestate === "Old" && claimstatus === "no") {
                total = total - 1000;
            }
        } else {
            baseamount = 4500;
            vehiclevalue = vehiclevalue * 0.15;
            total = baseamount + vehiclevalue;
            if (vehiclestate === "Old" && claimstatus === "no") {
                total = total - 1000;
            }
        }
        premiumAmount.value = total;
    }

    