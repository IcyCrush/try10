package com.admin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteUnderwriterTable {
	public static void deletetable(Connection con, String id) {
	    String tableName = "table_" + id;
	    String sql = "DROP TABLE " + tableName;
	    try {
	        PreparedStatement pstmt = con.prepareStatement(sql);
	        pstmt.executeUpdate(); // Use executeUpdate() for data manipulation queries
	        System.out.println("Table dropped successfully: " + tableName);
	    } catch (SQLException e) {
	        System.out.println("Error dropping table: " + e.getMessage());
	    }
	}

}
