package com.admin;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.login.DBConnection;

@WebServlet("/HelloServlet")
public class HelloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public HelloServlet() {
        super();

    }
    
 @Override
protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	 PrintWriter out=response.getWriter();
		out.println("Hello server");
		Connection conn = DBConnection.getConnection();
		int id=Integer.parseInt(request.getParameter("uid"));
		String name=request.getParameter("name");
		String dob=request.getParameter("dob");
		String doj=request.getParameter("doj");
		String password=request.getParameter("psw");
		out.println(name+" your id is "+id);
		out.println("your dob is:"+dob); 
		out.println("your doj is:"+doj); 
		out.println("your password is:"+password);
		NewUnderwriter.insertTable(conn,id,name,dob,doj,password);
		NewUnderwriter.createTable(conn, id);
		
}
 
 	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		service(request,response);
	}

}

