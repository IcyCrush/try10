package com.admin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class NewUnderwriter {
	public static void insertTable(Connection con,int id, String name, String dob, String doj, String password) {
		String sql = "insert into UnderW(id,name,dob,doj,password) values(?,?,?,?,?)";
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.setString(2, name);
            ps.setString(3, dob);
            ps.setString(4, doj);
            ps.setString(5, password);
            ps.execute();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
		
	}
	public static void createTable(Connection con, int id) {
	    String str = Integer.toString(id);
	    String sql = "CREATE TABLE table_" + str + " (" +
	                 "policyno INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), " +
	                 "vehicleno INTEGER, " +
	                 "vehicletype VARCHAR(20), " +
	                 "customername VARCHAR(20), " +
	                 "engineno INTEGER, " +
	                 "chasisno INTEGER, " +
	                 "phoneno BIGINT, " +
	                 "insurancetype VARCHAR(20), " +
	                 "premiumamount DECIMAL(10, 2), " +  // Using DECIMAL for precise monetary values
	                 "fromdate DATE, " +
	                 "todate DATE" +  // Removed the trailing comma
	                 ")";
	    try {
	        Statement s = con.createStatement();
	        s.execute(sql);
	        System.out.println("Table created successfully.");
	    } catch (Exception e) {
	        System.out.println("Error creating table: " + e.getMessage());
	    }
	}



}
