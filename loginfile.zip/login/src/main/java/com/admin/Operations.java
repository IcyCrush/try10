package com.admin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Operations {
	public static ArrayList<Underwriter> viewAllUnderWriters(Connection con){
		String sql="Select * from UnderW";
		ArrayList<Underwriter> underlist=new ArrayList<>();
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			ResultSet rs=pstmt.executeQuery();

			
			while(rs.next()) {
				Underwriter u=new Underwriter(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
				underlist.add(u);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return underlist;
		
	}
	public static ArrayList<Underwriter> viewbyId(Connection con,int id){
		String sql="Select * from UnderW where id=?";
		ArrayList<Underwriter> underlist=new ArrayList<>();
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setInt(1,id);
			ResultSet rs=pstmt.executeQuery();

			
			while(rs.next()) {
				Underwriter u=new Underwriter(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
				underlist.add(u);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return underlist;
	}
	
	public static int deletebyId(Connection con,String id){
		String sql="delete from underw where id=?";
		int rs=0;
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setString(1,id);
			rs=pstmt.executeUpdate();			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}
	public static int updatePass(Connection con,String password,int id) {
		String sql="update underw set password=? where id=?"; 
		int rs=0;
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setString(1,password);
			pstmt.setInt(2,id);
			rs=pstmt.executeUpdate();			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return rs;
	}
	public static ArrayList<Registration> viewAllVehicleById(Connection con,String id){
		String sql="Select * from Registration where underwriterid=?";
		ArrayList<Registration> vehiclelist=new ArrayList<>();
		try {
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setString(1,id);
			ResultSet rs=pstmt.executeQuery();

			
			while(rs.next()) {
				Registration u=new Registration(rs.getInt(2),rs.getString(3),rs.getString(4),rs.getInt(5),rs.getInt(6),rs.getLong(7),rs.getString(8),rs.getInt(9),rs.getDate(10),rs.getString(11));
				vehiclelist.add(u);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return vehiclelist;
	}
	

}
