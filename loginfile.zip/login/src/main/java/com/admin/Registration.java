package com.admin;

import java.sql.Date;

public class Registration {
	private int vehicleno;
	private String vehicletype;
	private String customername;
	private int engineno;
	private int chasisno;
	private long phoneno;
	private String insurancetype;
	private int premiumamount;
	private Date fromdate;
	private String underwriterid;
	public Registration(int vehicleno, String vehicletype, String customername, int engineno, int chasisno,
			long phoneno, String insurancetype, int premiumamount, Date fromdate, String underwriterid) {
		super();
		this.vehicleno = vehicleno;
		this.vehicletype = vehicletype;
		this.customername = customername;
		this.engineno = engineno;
		this.chasisno = chasisno;
		this.phoneno = phoneno;
		this.insurancetype = insurancetype;
		this.premiumamount = premiumamount;
		this.fromdate = fromdate;
		this.underwriterid=underwriterid;
	}
	public String getUnderwriterid() {
		return underwriterid;
	}
	public void setUnderwriterid(String underwriterid) {
		this.underwriterid = underwriterid;
	}
	public int getVehicleno() {
		return vehicleno;
	}
	public void setVehicleno(int vehicleno) {
		this.vehicleno = vehicleno;
	}
	public String getVehicletype() {
		return vehicletype;
	}
	public void setVehicletype(String vehicletype) {
		this.vehicletype = vehicletype;
	}
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	public int getEngineno() {
		return engineno;
	}
	public void setEngineno(int engineno) {
		this.engineno = engineno;
	}
	public int getChasisno() {
		return chasisno;
	}
	public void setChasisno(int chasisno) {
		this.chasisno = chasisno;
	}
	public long getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(long phoneno) {
		this.phoneno = phoneno;
	}
	public String getInsurancetype() {
		return insurancetype;
	}
	public void setInsurancetype(String insurancetype) {
		this.insurancetype = insurancetype;
	}
	public int getPremiumamount() {
		return premiumamount;
	}
	public void setPremiumamount(int premiumamount) {
		this.premiumamount = premiumamount;
	}
	public Date getFromdate() {
		return fromdate;
	}
	public void setFromdate(Date fromdate) {
		this.fromdate = fromdate;
	}
	@Override
	public String toString() {
		return "Registration [vehicleno=" + vehicleno + ", vehicletype=" + vehicletype + ", customername="
				+ customername + ", engineno=" + engineno + ", chasisno=" + chasisno + ", phoneno=" + phoneno
				+ ", insurancetype=" + insurancetype + ", premiumamount=" + premiumamount + ", fromdate=" + fromdate
				+ ", underwriterid=" + underwriterid + "]";
	}
	
	
	
}