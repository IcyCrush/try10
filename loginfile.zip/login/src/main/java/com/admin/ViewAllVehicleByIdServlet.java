package com.admin;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.login.DBConnection;


@WebServlet("/ViewAllVehicleByIdServlet")
public class ViewAllVehicleByIdServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public ViewAllVehicleByIdServlet() {
        super();

    }
    
protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	PrintWriter out=response.getWriter(); 
    	String id=request.getParameter("underid");
    	Connection conn = DBConnection.getConnection();
        ArrayList<Registration> vl=Operations.viewAllVehicleById(conn, id);
    	for(int i=0;i<vl.size();i++) {
    		out.println(vl.get(i));
    	}
			//response.sendRedirect("Admin-pages/UpdatebyId.jsp");
		
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		service(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		service(request,response);
	}

}
