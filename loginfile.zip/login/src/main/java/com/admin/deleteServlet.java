package com.admin;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.login.DBConnection;


@WebServlet("/deleteServlet")
public class deleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public deleteServlet() {
        super();
    }
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	PrintWriter out=response.getWriter();
    	Connection conn = DBConnection.getConnection();
		String sid=request.getParameter("deletebyid");
		out.println("id:"+sid);
		int ul=Operations.deletebyId(conn,sid);
		
		DeleteUnderwriterTable.deletetable(conn, sid);
		if(ul>0) {
			response.sendRedirect("Admin-pages/DeleteById.jsp");
		}
		else {
			out.println("No underwriter of the id found.");
		}
    	
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		service(request,response);
	}

}
