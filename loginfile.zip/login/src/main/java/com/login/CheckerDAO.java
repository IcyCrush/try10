package com.login;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class CheckerDAO {
    public static void insertChecker(Connection conn, String tablename) {
        try {
            String sql = "UPDATE checker SET tablename = ? WHERE name = 'ins'";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, tablename);
            pstmt.executeUpdate();
            System.out.println("Data entered successfully into checker table");
        } catch (Exception e) {
            e.printStackTrace(); 
        }
    }
}

