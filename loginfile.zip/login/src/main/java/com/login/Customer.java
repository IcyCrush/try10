package com.login;

public class Customer {
	private int id;
	private String pass;
	public Customer(int id, String pass) {
		super();
		this.id = id;
		this.pass = pass;
	}
	public int getid() {
		return id;
	}
	public void setName(int id) {
		this.id = id;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", pass=" + pass + "]";
	}
	
	
}
