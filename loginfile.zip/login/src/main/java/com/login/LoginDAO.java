package com.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class LoginDAO {
	public static ArrayList<Customer> getCustomer(Connection conn){
		ArrayList<Customer> customerList = new ArrayList<>();
		String sql ="select*from UNDERW";
		try {
			PreparedStatement pstmt =conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				Customer c =new Customer(rs.getInt(1),rs.getString(5));
				customerList.add(c);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return customerList;
		
	}
}
