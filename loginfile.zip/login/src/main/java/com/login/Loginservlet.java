package com.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Loginservlet")
public class Loginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public Loginservlet() {
        super();
        }

    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	Connection conn = DBConnection.getConnection();
    	ArrayList<Customer> data = LoginDAO.getCustomer(conn);
    	int id = Integer.parseInt(request.getParameter("customer_name"));
    	String pass =request.getParameter("customer_pass");
    	int count=0;
    	for(int i =0;i<data.size();i++) {
    		if(data.get(i).getid()==id && data.get(i).getPass().equals(pass)) {
    			count++;
    			String loadtable="table_"+id;
    			CheckerDAO.insertChecker(conn, loadtable);
    			response.sendRedirect("Underwriter-pages/underwriterdashboard.jsp");
    		}
    	}if(count==0) {
    		PrintWriter out = response.getWriter();
	    	out.println("User doesnt exist");
    	}
    	
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		service(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		service(request,response);
	}

}
