package com.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class UnderwriterDAO {
	public static ArrayList<Underwriters> getUnderwriter(Connection conn){
		ArrayList<Underwriters> underwriterList = new ArrayList<>();
		String sql ="select*from underwriters";
		try {
			PreparedStatement pstmt =conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				Underwriters c =new Underwriters(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5),rs.getLong(6),rs.getString(7),rs.getInt(8),rs.getDate(9));
				underwriterList.add(c);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return underwriterList;
		
	}
	public static void insertUnderwriter(Connection conn,Underwriters c) {
		try {
			String sql ="insert into underwriters values(vehicleno,vehicletype,customername,engineno,chasisno,phoneno,insurancetype,premiumamout,fromdate)(?,?,?,?,?,?,?,?,?)";
			PreparedStatement pstmt =conn.prepareStatement(sql);
			pstmt.setInt(1, c.getVehicleno());
			pstmt.setString(2, c.getVehicletype());
			pstmt.setString(3, c.getCustomername());
			pstmt.setInt(4, c.getEngineno());
			pstmt.setInt(5, c.getChasisno());
			pstmt.setLong(6, c.getPhoneno());
			pstmt.setString(7, c.getInsurancetype());
			pstmt.setInt(8, c.getPremiumamount());
			pstmt.setDate(9, c.getFromdate());
			pstmt.executeUpdate();
			System.out.println("data entered sucessfully");
		}catch(Exception e) {
			System.out.println("error in entering data"+e);
		}
	}
}
