package com.reg;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class ChangepolicyDAO {
	public static void changePolicy(Connection conn,int id) {
		try {
			String sql="update registration set insurancetype = 'Full Insurance' where policyno =?";
			PreparedStatement pstmt =conn.prepareStatement(sql);
			pstmt.setInt(1,id);
			pstmt.executeUpdate();
			System.out.println("insurance changed sucessfully");
		}catch(Exception e) {
			System.out.println("error in changing data"+e);
		}
	}
}
