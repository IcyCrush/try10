package com.reg;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
	static final String URL = "jdbc:derby:C:\\Users\\arsha\\MyDB;create=true";
	static final String DRIVERNAME = "org.apache.derby.jdbc.EmbeddedDriver";
	
	public static Connection getConnection() {
		Connection conn=null;
		
		try {
			Class.forName(DRIVERNAME);
			conn = DriverManager.getConnection(URL);
			System.out.println("connection established successfully");
		}
		catch(Exception e) {
			System.out.println("an error occured"+ e);
		}
		return conn;
	}
}
