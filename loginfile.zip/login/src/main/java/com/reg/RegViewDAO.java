package com.reg;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class RegViewDAO {
	public static ArrayList<RegView> getView(Connection conn){
		ArrayList<RegView> RegViewList = new ArrayList<>();
		String sql ="select*from registration";
		try {
			PreparedStatement pstmt =conn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				RegView t =new RegView(rs.getInt(1), rs.getInt(2), rs.getString(3),rs.getString(4),rs.getInt(5), rs.getInt(6), rs.getLong(7),rs.getString(8), rs.getInt(9), rs.getDate(10));
				RegViewList.add(t);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return RegViewList;
		
	}
}	
