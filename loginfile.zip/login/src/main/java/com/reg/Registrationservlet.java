package com.reg;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Registrationservlet")
public class Registrationservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Registrationservlet() {
        super();
        
    }

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	int vehicleno=Integer.parseInt(request.getParameter("vehicleno"));
    	String vehicletype =request.getParameter("vehicletype");
    	String customername=request.getParameter("customername");
    	int engineno=Integer.parseInt(request.getParameter("engineno"));
    	int chasisno=Integer.parseInt(request.getParameter("chasisno"));
    	long phoneno = Long.parseLong(request.getParameter("phoneno"));
    	String insurancetype =request.getParameter("insurancetype");
    	int premiumamount=Integer.parseInt(request.getParameter("premiumamount"));

    	Date fromdate = null;
        try {
        	fromdate = Date.valueOf(request.getParameter("fromdate"));
        } catch (IllegalArgumentException e) {
            // Handle invalid date format
            e.printStackTrace();
            // You might want to provide a response to the user indicating the date format is invalid
            return;
        }
        Registration newReg =new Registration(vehicleno,vehicletype,customername,engineno,chasisno,phoneno,insurancetype,premiumamount,fromdate);
        Connection conn = DBConnection.getConnection();
        RegistrationDAO.insertReg(conn, newReg);
        response.sendRedirect("RegistrationView.jsp");
    	
    	try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		service(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		service(request,response);
	}

}
