package com.underwriter;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class ChangepolicyDAO {
	public static void changePolicynew(Connection conn,int id,String check) {
		try {
			String sql="update "+check+" set insurancetype = 'Full Insurance' where policyno =?";
			PreparedStatement pstmt =conn.prepareStatement(sql);
			pstmt.setInt(1,id);
			pstmt.executeUpdate();
			System.out.println("insurance changed sucessfully");
		}catch(Exception e) {
			System.out.println("error in changing data"+e);
		}
	}
}
