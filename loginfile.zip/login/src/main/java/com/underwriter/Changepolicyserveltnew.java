package com.underwriter;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Changepolicyserveltnew")
public class Changepolicyserveltnew extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Changepolicyserveltnew() {
        super();
        
    }
	
protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	int policyid=Integer.parseInt(request.getParameter("policyid"));
	Connection conn = DBConnection.getConnection();
	String check =CheckerDAO.getTableName(conn);
	ChangepolicyDAO.changePolicynew(conn,policyid,check);
	response.sendRedirect("Underwriter-pages/changepolicysuccess.jsp");
}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		service(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		service(request,response);
	}

}
