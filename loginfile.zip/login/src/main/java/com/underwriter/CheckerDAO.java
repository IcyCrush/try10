package com.underwriter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CheckerDAO {
    public static String getTableName(Connection conn) {
        String sql = "SELECT tablename FROM checker"; 
        String tableName = null;
        try {
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) { 
                tableName = rs.getString("tablename"); 
            }
            rs.close();
            pstmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tableName;
    }
}
