package com.underwriter;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;


public class PremiumDAO {
	

	public static void insertUnderwriter(Connection conn, int vehicleno, String vehicletype, String customername,
			int engineno, int chasisno, long phone, String insurancetype, double total, Date fromdate, Date todate,String getTableName) {
		try {
			String check =getTableName;
			String sql ="insert into "+check +" values(default,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement pstmt =conn.prepareStatement(sql);
			pstmt.setInt(1, vehicleno);
			pstmt.setString(2, vehicletype);
			pstmt.setString(3, customername);
			pstmt.setInt(4, engineno);
			pstmt.setInt(5, chasisno);
			pstmt.setLong(6, phone);
			pstmt.setString(7, insurancetype);
			pstmt.setDouble(8, total);
			pstmt.setDate(9, fromdate);
			pstmt.setDate(10, todate);
			pstmt.executeUpdate();
			System.out.println("data entered sucessfully in underwriter custom table");
		}catch(Exception e) {
			System.out.println("error in entering data in underwriter custom table     "+e);
		}
		
	}
	public static void createtableunderwriter(Connection conn,String tablename) {
		try {
			String sql = "create table "+tablename+
							"(policyno integer not null generated always as identity(start with 1,increment by 1),"+
							"vehicleno integer,"+
							"vehicletype varchar(20),"+
							"customername varchar(20),"+
							"engineno integer,"+
							"chasisno integer,"+
							"phoneno BIGINT,"+
							"insurancetype varchar(20),"+
							"premiumamount integer,"+
							"fromdate date,"+
							"todate date)";
			PreparedStatement pstmt =conn.prepareStatement(sql);
			pstmt.execute();
			System.out.println("created table sucessfully in underwriter custom");
		}catch(Exception e) {
			System.out.println("error in creating table in underwriter custom table     "+e);
		}
	}
}
	
