package com.underwriter;

import java.io.IOException;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.login.DBConnection;


@WebServlet("/Premiumservlet")
public class Premiumservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Premiumservlet() {
        super();
        
    }

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	
    	int vehicleno =Integer.parseInt(request.getParameter("vehicleno"));
    	String vehicletype =request.getParameter("vehicletype");
    	String customername =request.getParameter("customername");
    	int engineno=Integer.parseInt(request.getParameter("engineno"));
    	int chasisno=Integer.parseInt(request.getParameter("chasisno"));
    	long phone = Long.parseLong(request.getParameter("phone"));
    	String insurancetype=request.getParameter("insurancetype");
    	double vehiclevalue=Integer.parseInt(request.getParameter("vehiclevalue"));
    	String vehiclestate=request.getParameter("vehiclestate");
    	String claimstatus=request.getParameter("claimstatus");
    	Date fromdate = null;
        try {
        	fromdate = Date.valueOf(request.getParameter("fromdate"));
        } catch (IllegalArgumentException e) {
            // Handle invalid date format
            e.printStackTrace();
            // You might want to provide a response to the user indicating the date format is invalid
            return;
        }
        int baseamount=0;
        double total=0;
        if(insurancetype.equals("2 Wheeler")) {
        	baseamount=2500;
        	vehiclevalue =vehiclevalue* 0.1;
        	total=baseamount+vehiclevalue;
        	if(vehiclestate.equals("Old")&& claimstatus.equals("no")) {
        		total =total-1000;
        	}
        }else {
        	baseamount=4500;
        	vehiclevalue =vehiclevalue* 0.5;
        	total=baseamount+vehiclevalue;
        	if(vehiclestate.equals("Old")&& claimstatus.equals("no")) {
        		total =total-1000;
        	}
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(fromdate);
        calendar.add(Calendar.YEAR, 1); 
        Date todate = new Date(calendar.getTimeInMillis());
    	
    	Connection conn = DBConnection.getConnection();
    	
    	String check =CheckerDAO.getTableName(conn);
    	PremiumDAO.insertUnderwriter(conn, vehicleno,vehicletype,customername,engineno,chasisno,phone,insurancetype,total,fromdate,todate,check);
    	
    	
    	try {
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		service(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		service(request,response);
	}

}


