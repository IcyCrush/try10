package com.underwriter;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RenewpolicyDAO {
    public static void insertToDate(Connection conn, int id, String check, Date toDate) {
        try {
            String sql = "UPDATE " + check + " SET todate = ? WHERE policyno = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setDate(1, toDate);
            pstmt.setInt(2, id);
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Insurance renewed successfully for policy number: " + id);
            } else {
                System.out.println("Failed to renew insurance for policy number: " + id);
            }
        } catch (SQLException e) {
            System.out.println("Error in changing data: " + e.getMessage());
            
        }
    }
}
