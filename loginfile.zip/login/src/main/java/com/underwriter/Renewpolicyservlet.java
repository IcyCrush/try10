package com.underwriter;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Renewpolicyservlet")
public class Renewpolicyservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Renewpolicyservlet() {
        super();
     
    }
    
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int policyid = Integer.parseInt(request.getParameter("policynumber"));
        Connection conn = DBConnection.getConnection();
        String check = CheckerDAO.getTableName(conn);
        LocalDate currentDate = LocalDate.now();
        Date sqlDate = Date.valueOf(currentDate); 
        RenewpolicyDAO.insertToDate(conn, policyid, check, sqlDate);
        response.sendRedirect("Underwriter-pages/renewpolicysuccess.jsp");
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		service(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		service(request,response);
	}

}
