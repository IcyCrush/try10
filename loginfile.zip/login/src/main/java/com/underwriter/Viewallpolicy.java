package com.underwriter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class Viewallpolicy {
    public static ArrayList<Policies> viewallpolicy(Connection con, String id) {
        String sql = "SELECT * FROM " + id;
        ArrayList<Policies> policylist = new ArrayList<>();
        try {
            PreparedStatement pstmt = con.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Policies policy = new Policies(
                        rs.getInt(1),      
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getInt(5),
                        rs.getInt(6),
                        rs.getLong(7),
                        rs.getString(8),
                        rs.getDouble(9),
                        rs.getDate(10),
                        rs.getDate(11)
                );
                policylist.add(policy);
            }
        } catch (SQLException e) {
            // Handle SQLException gracefully
            e.printStackTrace(); // Consider logging the error instead
        }
        return policylist;
    }
}

